module.exports = [
  {
    name: "Basic Tee (Sienna)",
    price: 3200,
    currency: "USD",
    image:
      "https://epic-projects.nyc3.digitaloceanspaces.com/react-ecommerce/basic-tee-sienna.jpeg",
  },
  {
    name: "Basic Tee (Black)",
    price: 3200,
    currency: "USD",
    image:
      "https://epic-projects.nyc3.digitaloceanspaces.com/react-ecommerce/basic-tee-black.jpeg",
  },
  {
    name: "Nomad Tumbler",
    price: 3500,
    currency: "USD",
    image:
      "https://epic-projects.nyc3.digitaloceanspaces.com/react-ecommerce/nomad-tumbler.jpeg",
  },
  {
    name: "Artwork Tee",
    price: 3200,
    currency: "USD",
    image:
      "https://epic-projects.nyc3.digitaloceanspaces.com/react-ecommerce/artwork-tee.jpeg",
  },
  {
    name: "Billfold Wallet",
    price: 11800,
    currency: "USD",
    image:
      "https://epic-projects.nyc3.digitaloceanspaces.com/react-ecommerce/billfold-wallet.jpeg",
  },
  {
    name: "Mini Sketchbook Set",
    price: 2800,
    currency: "USD",
    image:
      "https://epic-projects.nyc3.digitaloceanspaces.com/react-ecommerce/mini-sketchbook-set.jpeg",
  },
  {
    name: "Organize Set",
    price: 14900,
    currency: "USD",
    image:
      "https://epic-projects.nyc3.digitaloceanspaces.com/react-ecommerce/organize-set.jpeg",
  },
  {
    name: "Machined Pen & Pencil",
    price: 7000,
    currency: "USD",
    image:
      "https://epic-projects.nyc3.digitaloceanspaces.com/react-ecommerce/machine-pen-pencil-set.jpeg",
  },
];
